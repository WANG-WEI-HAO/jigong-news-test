// functions/index.js (最終整合版)

// 導入 dotenv 並在最頂部進行配置，以載入 .env 檔案中的變數
require('dotenv').config();

const admin = require("firebase-admin");
const { onRequest } = require("firebase-functions/v2/https");
const { setGlobalOptions } = require("firebase-functions/v2");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const express = require('express');
const cors = require('cors');
const webpush = require('web-push');
const { JobsClient } = require('@google-cloud/run');

// --- 初始化 ---
admin.initializeApp();
const db = admin.firestore();
// 設定 Cloud Functions 的預設地區
setGlobalOptions({ region: 'us-central1' }); // 您可以換成 'asia-east1' 等離您近的地區

const app = express();

// --- 中介軟體設定 ---
// 為了安全，只允許來自您 PWA 網站的請求
app.use(cors({ origin: 'https://jigong-news-live.web.app' }));
app.use(express.json());

// --- 輔助函數 ---
function safeEncode(str) {
  if (!str) return null;
  return Buffer.from(str).toString('base64').replace(/\//g, '_');
}

// --- VAPID 金鑰初始化 (從 process.env 讀取) ---
try {
  const vapidPublicKey = process.env.VAPID_PUBLIC_KEY;
  const vapidPrivateKey = process.env.VAPID_PRIVATE_KEY;
  let email = process.env.VAPID_MAILTO;
  
  if (!email) {
    console.warn("警告：VAPID_MAILTO 未設定，將使用預設郵箱。");
    email = 'mailto:your-default-email@example.com';
  } else if (!email.startsWith('mailto:')) {
    email = `mailto:${email}`;
  }

  if (!vapidPublicKey || !vapidPrivateKey) {
    console.error("啟動錯誤：VAPID_PUBLIC_KEY 或 VAPID_PRIVATE_KEY 未在環境變數中設定！");
  } else {
    webpush.setVapidDetails(email, vapidPublicKey, vapidPrivateKey);
    console.log("WebPush VAPID 金鑰已成功從環境變數設定。");
  }
} catch (error) {
  console.error("設定 WebPush 時發生嚴重錯誤:", error.message);
}

// ==========================================================
// --- API 路由 (API Endpoints) ---
// ==========================================================

// 提供公鑰給前端
app.get('/vapid-public-key', (req, res) => {
  const publicKey = process.env.VAPID_PUBLIC_KEY;
  if (!publicKey) {
    return res.status(500).send("VAPID Public Key is not configured on the server.");
  }
  res.set('Cache-Control', 'public, max-age=86400'); // 快取一天
  res.status(200).send(publicKey);
});

// 處理新的訂閱
app.post('/subscribe', async (req, res) => {
  const subscription = req.body;
  if (!subscription || !subscription.endpoint) {
    return res.status(400).json({ error: "無效的訂閱物件。" });
  }
  try {
    const docId = safeEncode(subscription.endpoint);
    const dataToSave = {
      ...subscription,
      createdAt: admin.firestore.FieldValue.serverTimestamp(),
      lastSeen: admin.firestore.FieldValue.serverTimestamp(),
    };
    await db.collection('subscriptions').doc(docId).set(dataToSave);
    console.log("成功儲存訂閱，文件 ID:", docId);
    res.status(201).json({ message: "Subscription added successfully." });
  } catch (error) {
    console.error("Firestore 寫入失敗:", error);
    res.status(500).json({ error: "Failed to save subscription." });
  }
});

// 處理取消訂閱
app.post('/unsubscribe', async (req, res) => {
  const { endpoint } = req.body;
  if (!endpoint) {
    return res.status(400).json({ error: "缺少訂閱的 endpoint。" });
  }
  try {
    const docId = safeEncode(endpoint);
    await db.collection('subscriptions').doc(docId).delete();
    res.status(200).json({ message: "Subscription removed successfully." });
  } catch (error) {
    console.error("Firestore 刪除失敗:", error);
    res.status(500).json({ error: "Failed to remove subscription." });
  }
});

// 處理前端的心跳回報
app.post('/heartbeat', async (req, res) => {
  const { endpoint } = req.body;
  if (!endpoint) {
    return res.status(400).json({ error: "缺少 endpoint。" });
  }
  try {
    const docId = safeEncode(endpoint);
    await db.collection('subscriptions').doc(docId).update({
      lastSeen: admin.firestore.FieldValue.serverTimestamp()
    });
    res.status(200).json({ message: "Heartbeat successful." });
  } catch (error) {
    res.status(200).json({ message: "Heartbeat failed, device might be new or cleared." });
  }
});

// 【核心路由】接收來自 Python 的特定推播內容並發送
app.post('/send-daily-notification', async (req, res) => {
  console.log("收到特定內容推播請求:", req.body);
  const { title, body, image, url } = req.body;

  if (!title || !body) {
    return res.status(400).json({ error: "請求中缺少 'title' 或 'body'。" });
  }

  const payload = JSON.stringify({
    title: title,
    body: body,
    image: image || '',
    url: url || process.env.PWA_BASE_URL || 'https://jigong-news-live.web.app',
    icon: `${process.env.PWA_BASE_URL || 'https://jigong-news-live.web.app'}/icons/icon-192.png`,
  });

  try {
    const snapshot = await db.collection('subscriptions').get();
    if (snapshot.empty) {
      console.log("沒有找到任何訂閱者。");
      return res.status(200).json({ message: "No subscribers to notify." });
    }
    
    const subscriptions = snapshot.docs.map(doc => doc.data());
    const pushPromises = subscriptions.map(sub => 
        webpush.sendNotification(sub, payload).catch(async (err) => {
            if (err.statusCode === 404 || err.statusCode === 410) {
                const docIdToDelete = safeEncode(err.endpoint || sub.endpoint);
                if(docIdToDelete) {
                    await db.collection('subscriptions').doc(docIdToDelete).delete();
                    console.log(`偵測並刪除了失效的訂閱: ${docIdToDelete}`);
                }
            } else {
                console.error('發送推播失敗 (非 404/410):', err.statusCode, err.body);
            }
        })
    );
    
    await Promise.all(pushPromises);
    
    console.log(`特定內容推播任務完成，嘗試發送給 ${subscriptions.length} 位訂閱者。`);
    res.status(200).json({ message: `Push notifications sent to ${subscriptions.length} subscribers.` });

  } catch (error) {
    console.error("處理特定內容推播時發生嚴重錯誤:", error);
    res.status(500).json({ error: "Failed to send notifications.", details: error.message });
  }
});

// 將 Express 應用程式導出為 HTTP 觸發的 Cloud Function
exports.api = onRequest(app);


// ==========================================================
// --- 排程函式：每天自動清理殭屍訂閱 ---
// ==========================================================
exports.cleanupzombiesubscriptions = onSchedule("every day 04:00", async (event) => {
  console.log("開始執行每日殭屍訂閱清理任務...");
  const threeDaysAgo = new Date();
  threeDaysAgo.setDate(threeDaysAgo.getDate() - 3);
  const threeDaysAgoTimestamp = admin.firestore.Timestamp.fromDate(threeDaysAgo);

  try {
    const oldSubscriptionsQuery = db.collection('subscriptions').where('lastSeen', '<', threeDaysAgoTimestamp);
    const snapshot = await oldSubscriptionsQuery.get();

    if (snapshot.empty) {
      console.log("沒有找到需要清理的過期訂閱。");
      return null;
    }
    const batch = db.batch();
    snapshot.forEach(doc => {
      batch.delete(doc.ref);
    });
    await batch.commit();
    console.log(`成功刪除了 ${snapshot.size} 個過期的殭屍訂閱。`);
    return null;
  } catch (error) {
    console.error("清理殭屍訂閱任務失敗:", error);
    return null;
  }
});

// ==========================================================
// --- Cloud Run 作業觸發器 (Job Trigger Function) ---
// ==========================================================

 //這個函式會被 Cloud Scheduler 呼叫，然後它再去安全地執行 Cloud Run Job
exports.jobTriggerFunction = onRequest(async (req, res) => {
  console.log('接收到 Cloud Scheduler 的觸發請求，準備執行 telegram-importer-job...');

  // 從環境變數獲取配置，如果沒有則使用預設值
  // 確保這些值與您的專案設定一致
  const projectId = process.env.GCLOUD_PROJECT || 'jigong-news-live';
  const region = process.env.CLOUD_RUN_REGION || 'us-central1'; 
  const jobName = process.env.CLOUD_RUN_JOB_NAME || 'telegram-importer-job';

  // 初始化 Cloud Run API 客戶端
  const client = new JobsClient();
  
  // 組合出要執行的 Job 的完整名稱
  const name = client.jobPath(projectId, region, jobName);

  try {
    // 執行 Cloud Run Job，這是一個非同步操作
    const [operation] = await client.runJob({ name });
    console.log(`成功觸發 Cloud Run Job 的執行操作: ${operation.name}`);
    
    // 立即回應給 Cloud Scheduler，告訴它觸發成功，不需要等待 Job 完成
    res.status(200).send({ message: 'Cloud Run Job 已成功觸發。' });
  } catch (error) {
    console.error('觸發 Cloud Run Job 失敗:', error);
    res.status(500).send({ error: `觸發 Job 失敗: ${error.message}` });
  }
});